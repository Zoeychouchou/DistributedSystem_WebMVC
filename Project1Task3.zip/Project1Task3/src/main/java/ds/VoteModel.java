package ds;

/*
 * @author I-Wen (Zoey) Chou, andrewID:ichou
 *reference:lab2 practice code, @author Joe Mertz
 *
 */

import java.util.Map;
import java.util.TreeMap;

public class VoteModel {
    //create a treemap for data sequence
    static Map<String, Integer> map = new TreeMap<String, Integer>();

    public VoteModel() {
        map.put("A", 0);
        map.put("B", 0);
        map.put("C", 0);
        map.put("D", 0);
    }

    //add 1 to count number of the vote(A, B, C, or D)
    public Map doVoteCount(String nvote) {
        map.put(nvote, map.get(nvote) + 1);
        return map;
    }

    //get vote result as treemap
    public Map getVoteCount() {
        int sum = 0;
        //check if there's no results
        for (int i : map.values()) {
            sum += i;
        }
        if (sum == 0) {
            return null;
        }
        //after showing the result, the stored results are cleared so that a new question can be posed
        Map<String, Integer> result = new TreeMap<>();
        for (Map.Entry m : map.entrySet()) {
            result.put((String) m.getKey(), (Integer) m.getValue());
            map.put((String) m.getKey(), 0);
        }
        return result;
    }
}
