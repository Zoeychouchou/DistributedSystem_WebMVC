package ds;
/*
 * @author I-Wen (Zoey) Chou, andrewID:ichou
 *reference:lab2 practice code from @author Joe Mertz
 *
 */

import java.io.IOException;
import java.util.Map;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

/*
 *
 */
@WebServlet(name = "VoteServlet",
        urlPatterns = {"/getAnVote", "/submit", "/getResults"})
public class VoteServlet extends HttpServlet {

    VoteModel vm = null;  // The "business model" for this app

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        vm = new VoteModel();
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // determine what type of device our user is
        String ua = request.getHeader("User-Agent");

        /*
         *reference:lab2 practice code, @author Joe Mertz
         */
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        /*
         *reference end
         */

        String nextView;
        //change view depends on servlet path
        String path = request.getServletPath();
        if (path.equals("/getResults")) {
            //get map data from model
            Map<String, Integer> newMap = vm.getVoteCount();
            //set map data to view
            request.setAttribute("voteCount", newMap);
            //show "result.jsp" view for result
            nextView = "result.jsp";
        } else {
            //show "prompt.jsp" view for initial page and vote submit
            nextView = "prompt.jsp";
        }
        // Transfer control over the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        // determine what type of device our user is
        String ua = request.getHeader("User-Agent");

        /*
         *reference:lab2 practice code, @author Joe Mertz
         */
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        /*
         *reference end
         */

        //get vote value from view
        String vote = request.getParameter("vote");
        //based on vote value update vote result in model
        vm.doVoteCount(vote);
        //set vote value(A, B, C, or D) to view
        request.setAttribute("voteMessage", String.format("Your \"%s\" has been registered", vote));
        //show "prompt.jsp" view
        RequestDispatcher view = request.getRequestDispatcher("prompt.jsp");
        view.forward(request, resp);
    }
}
