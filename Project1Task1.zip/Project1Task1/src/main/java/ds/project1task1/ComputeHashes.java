package ds.project1task1;
/*
 * @author I-Wen (Zoey) Chou, andrewID:ichou
 */

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@WebServlet(name = "ComputeHashes", urlPatterns = {"/getHashCode"})
public class ComputeHashes extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Get search text and the hashcode method from website
        String search = request.getParameter("str");
        String hashMethod = request.getParameter("hash_method");
        byte[] hashResult;

        //reference:lab2 practice code, @author Joe Mertz
        // determine what type of device our user is
        String ua = request.getHeader("User-Agent");
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        //reference-end

        String nextView = "index.jsp";
        String base64;
        String hex;

        //determine hashcode method
        if (search != null) {
            //hashcode method equals to MD5
            if (hashMethod.equals("MD5")) {
                try {
                    MessageDigest md = MessageDigest.getInstance("MD5");
                    hashResult = md.digest(search.getBytes("UTF-8"));
                    //print the base64 encoding
                    base64 = javax.xml.bind.DatatypeConverter.printBase64Binary(hashResult);
                    //print hexadecimal encoding
                    hex = javax.xml.bind.DatatypeConverter.printHexBinary(hashResult);
                    //set base64 and hexadecimal encoding attribute back to the view
                    request.setAttribute("base64", base64);
                    request.setAttribute("hex", hex);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
                //hashcode method equals to SHA-256
            } else if (hashMethod.equals("SHA256")) {
                try {
                    MessageDigest sha = MessageDigest.getInstance("SHA-256");
                    hashResult = sha.digest(search.getBytes("UTF-8"));
                    //print the base64 encoding
                    base64 = javax.xml.bind.DatatypeConverter.printBase64Binary(hashResult);
                    //print hexadecimal encoding
                    hex = javax.xml.bind.DatatypeConverter.printHexBinary(hashResult);
                    //set base64 and hexadecimal encoding attribute back to the view
                    request.setAttribute("base64", base64);
                    request.setAttribute("hex", hex);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}