package ds;

/*
 * @author I-Wen (Zoey) Chou, andrewID:ichou
 *reference:lab2 practice code, @author Joe Mertz
 *
 */

import java.io.*;
import java.net.URL;
import java.util.Scanner;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class StateInformationModel {

    /**
     * Arguments.
     *
     * @param state     The tag of the photo to be searched for.
     * @param 'picSize' The string "mobile" or "desktop" indicating the size of
     *                  photo requested.
     */

    //Get POPULATION data of the selected state
    public String doPopulationSearch(String state)
            throws UnsupportedEncodingException {

        String population = "";
        String stateNum = "";
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();

            //read state code file
            StringBuilder fileContent = new StringBuilder();
            URL url = this.getClass().getClassLoader().getResource("fips.csv");
            Scanner input = new Scanner(new File(url.getFile()));
            while (input.hasNextLine()) {
                fileContent.append(input.nextLine() + "\n");
            }
            input.close();

            //get state code
            String[] rows = fileContent.toString().split("\n");
            for (int i = 0; i < rows.length; i++) {
                String[] column = rows[i].split(",");
                String st = column[0];
                if (st.equalsIgnoreCase(state)) {
                    stateNum = column[1];
                    break;
                }
            }

            //set population url with new state code
            String httpUrl = "https://api.census.gov/data/2020/dec/pl?get=NAME,P1_001N&for=state:" + stateNum + "&key=e0accfa0b2d9291776cc07ab926bab1494d291ea";

            //get population data via json type
            HttpGet request = new HttpGet(httpUrl);
            CloseableHttpResponse response = httpClient.execute(request);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // return it as a String
                String result = EntityUtils.toString(entity);
                //store as json type
                JsonNode json = new ObjectMapper().readTree(result);
                //extract population data
                int statepopulation = json.get(1).get(1).asInt();
                System.out.println(statepopulation);
                population = String.valueOf(statepopulation);
            }
            response.close();
            httpClient.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return population;
    }

    //Get NICKNAME data of the selected state
    public String doNicknameSearch(String state) {
        String statename = "";
        String nickname = "";
        try {
            //fetch content from the web and parse them into document
            Document doc = Jsoup.connect("https://britannica.com/topic/List-of-nicknames-of-U-S-States-2130544").get();
            Elements stateClass = doc.select("div.md-drag.md-table-wrapper tbody tr");
            for (int i = 0; i < stateClass.size(); i++) {
                Element tr = stateClass.get(i);
                //get state name in web content
                statename = tr.getElementsByClass("md-crosslink").get(0).html();
                //check state name and get nickname in web content
                if (statename.equals(state)) {
                    nickname = tr.getElementsByTag("td").get(1).html();
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return nickname;
    }

    //Get CAPITAL data of the selected state
    public String doCapitalSearch(String state) {

        String capital = "";
        try {
            //fetch content from the web and parse them into document
            Document doc = Jsoup.connect("https://gisgeography.com/united-states-map-with-capitals/").get();
            Elements stateClass = doc.select("#kt-layout-id_3ca99a-56 div div div p");
            //get state name in web content
            for (int j = 0; j < stateClass.size(); j++) {
                String[] stateCapitalString = stateClass.get(j).html().split("<br>");
                for (int i = 0; i < stateCapitalString.length; i++) {
                    String[] stateCapital = stateCapitalString[i].replace(")", "").split("\\(");
                    //check state name and get capital in web content
                    if (stateCapital[0].trim().equals(state)) {
                        capital = stateCapital[1].trim();
                        System.out.println(capital);
                    } else {
                        System.out.println(stateCapital[0].trim() + "," + stateCapital[1].trim());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return capital;
    }

    //Get SONG data of the selected state
    public String doSongSearch(String state)
            throws IOException {
        String song = "";
        String statename = "";

        //fetch content from the web and parse them into document
        Document doc = Jsoup.connect("https://www.50states.com/songs/").get();
        Elements stateClass = doc.select("div.rounded table tbody tr ul li");
        //get state name in web content
        for (int i = 0; i < stateClass.size(); i++) {
            Element dt = stateClass.get(i).select("dt").get(0);
            statename = dt.html();
            Elements dd = stateClass.get(i).select("dd a");
            if (dd.size() > 0) {
                song = dd.get(0).html();
            }
            //check state name and break from the loop, then return song name
            if (statename.equalsIgnoreCase(state)) {
                break;
            }
        }
        return song;
    }

    //Get FLOWER data of the selected state
    public String doFlowerSearch(String state) throws IOException {
        String flower = "";

        //fetch content from the web and parse them into document
        Document doc1 = Jsoup.connect("https://statesymbolsusa.org/categories/flower").get();
        Elements stateClass1 = doc1.select("div.view-content div.item-list ul li");
        String stateName = "";
        String img = "";

        //get state name in web content
        for (int i = 0; i < stateClass1.size(); i++) {
            Element li = stateClass1.get(i);
            //get state flower image url
            if (li.getElementsByTag("a").size() >= 3) {
                stateName = li.getElementsByTag("a").get(1).html();
                img = li.getElementsByTag("img").get(0).attr("src");
            }
            //check state name and break from the loop, then return flower image url
            if (stateName.equalsIgnoreCase(state)) {
                flower = img;
                break;
            }
        }
        return flower;
    }

    //Get FLAG data of the selected state
    public String doFlagSearch(String state) throws IOException {
        String flag = "";

        //fetch content from the web and parse them into document
        Document doc2 = Jsoup.connect("https://www.states101.com/flags").get();
        Elements stateClass2 = doc2.select("div.row-fluid div.col-md-10 div.row div");
        String stateName = "";
        String img = "";

        for (int i = 0; i < stateClass2.size(); i++) {
            Element div = stateClass2.get(i);
            //get state flag image url
            if (div.getElementsByTag("a").size() >= 0) {
                stateName = div.getElementsByTag("b").get(0).html().toString();
                img = div.getElementsByTag("img").get(0).attr("src");
            }
            //check state name and break from the loop, then return flag image url
            if (stateName.equalsIgnoreCase(state)) {
                flag = "https://www.states101.com" + img;
                break;
            }
        }
        return flag;
    }
}
